import cv2
import numpy as np
from PIL import ImageEnhance, Image

def get_box_coord(center, radius, width):
    left_coord = int(center - radius)
    right_coord = int(center + radius)
    if left_coord < 0:
        right_coord += abs(left_coord)
        left_coord = 0

    if right_coord > width:
        left_coord -= abs(width-right_coord) 
        right_coord = width
    return left_coord, right_coord


def get_cropped_frame(frame, center, radius=int(310/2)):
    height, width = frame.shape[:2]
    left_coord, right_coord = get_box_coord(center, radius, width)
    cropped_frame = frame[20:height-20, left_coord:right_coord]
    return cropped_frame

import cv2
import numpy as np
from PIL import ImageEnhance, Image

# Setup SimpleBlobDetector parameters.
params = cv2.SimpleBlobDetector_Params()

# Change thresholds
params.filterByColor = True
params.blobColor = 0 # black

# Filter by Area.
params.filterByArea = True
params.minArea = 50
params.maxArea = 500
# Filter by Circularity
params.filterByCircularity = True
params.minCircularity = 0.1

# Filter by Convexity
params.filterByConvexity = True
params.minConvexity = 0.7

# Filter by Inertia
params.filterByInertia = True
params.minInertiaRatio = 0.01

class CellsCounter():
    def __init__(self, k_close=5) -> None:
        self.kernel_close  = np.ones((k_close, k_close))
        self.blob_detector = cv2.SimpleBlobDetector_create(params) 

    def apply_filter(self, frame):
        pil_frame = Image.fromarray(frame)
        contrasted_frame = np.array(ImageEnhance.Contrast(pil_frame).enhance(1.5)) # contrast
        # img_blur = cv2.bilateralFilter(contrasted_frame, 15, 175, 50) # blur
        img_blur = cv2.GaussianBlur(contrasted_frame, (15,15), cv2.BORDER_DEFAULT)
        img_blur_dilated = cv2.dilate(img_blur, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (6, 6)), iterations=2) # dilate circle elements

        img_canny = cv2.Canny(image=img_blur_dilated, threshold1=15, threshold2=50) # border detection
        img_canny_dilate = cv2.dilate(img_canny, self.kernel_close,iterations = 1) # dilate border to merge border

        return img_canny_dilate

    def counts(self, frame):
        keypoints = self.blob_detector.detect(frame) # detect blob
        return len(keypoints)

    def execute(self, frame):
        filtered_frame = self.apply_filter(frame)
        return self.counts(filtered_frame), filtered_frame

