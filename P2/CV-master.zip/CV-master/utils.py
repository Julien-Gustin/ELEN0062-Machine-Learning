import cv2 
import numpy as np 

def adjust_gamma(image, gamma=1.0):
	# build a lookup table mapping the pixel values [0, 255] to
	# their adjusted gamma values
	invGamma = 1.0 / gamma
	table = np.array([((i / 255.0) ** invGamma) * 255
		for i in np.arange(0, 256)]).astype("uint8")
	# apply gamma correction using the lookup table
	return cv2.LUT(image, table)

def apply_hough_transform(frame) -> tuple:
    rows = frame.shape[0]
    circles = cv2.HoughCircles(frame, cv2.HOUGH_GRADIENT, 1, 1600,
                        param1=300, param2=20,
                        minRadius=120, maxRadius=195) # 100, 170

    centers = []
    radius_list = []

    if circles is not None: # take the bigger one (take care that it choose only one circle in the image !)
        max_radius = -np.inf
        center = None
        circles = np.uint16(np.around(circles))
        for i in circles[0, :]:
            radius = i[2]
            center = (i[0], i[1])
            centers.append(center)
            radius_list.append(radius)


        return centers, radius_list

    return None, None

font = cv2.FONT_HERSHEY_SIMPLEX
def display(frame, frame_nb=None, centers=None, radius_list=None, squares=None, name="my webcam", cnt=None):
    BGR_frame = cv2.cvtColor(frame, cv2.COLOR_GRAY2BGR)
    if centers is not None and radius_list is not None:
        for center, radius in zip(centers, radius_list):
            # circle center
            cv2.circle(BGR_frame, center, 1, (0, 100, 100), 3)
            # circle outline
            cv2.circle(BGR_frame, center, radius, (255, 0, 255), 3)

            rectangle_diameter = 310
            height, width = BGR_frame.shape[:2]

            top_left = (int(center[0] - rectangle_diameter/2), 0)
            down_right = (int(center[0] + rectangle_diameter/2), height)

            cv2.rectangle(BGR_frame, top_left , down_right, (255, 0, 0), 2)

    if cnt is not None:
        a = 0
        for nb_cell, count in cnt.items():
            cv2.putText(BGR_frame, '{}:{}'.format(nb_cell, count), (200*a, 50), font, 2, (255,0,0), 2, cv2.LINE_AA)
            a += 1

    if frame_nb is not None:
        cv2.putText(BGR_frame, '{}'.format(frame_nb), (0,230), font, 2, (0,255,0), 2, cv2.LINE_AA)
    cv2.imshow(name, BGR_frame)