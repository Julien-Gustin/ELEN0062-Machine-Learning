from typing import Counter
import cv2
import numpy as np
from PIL import ImageEnhance, Image

from utils import adjust_gamma, apply_hough_transform

def contrast(frame, v):
    frame = Image.fromarray(frame)
    frame = np.array(ImageEnhance.Contrast(frame).enhance(v))
    return frame

class DropletDetector():
 
    def __init__(self, initial_diameter, initial_velocity, update_every) -> None:
        self.bs = cv2.createBackgroundSubtractorMOG2(varThreshold=2.5, detectShadows=False)
        self.frame = None
        self.contours = None
        self.droplets = None
        self.nb_new_droplets = 0 

        self.diameter = initial_diameter
        self.velocity = initial_velocity
        self.update_every = update_every
        self.counter = 0
        self.update_flag = False



    def _applyFilters(self):
        kernel = np.ones((6, 6), np.uint8)
        self.frame = contrast(self.frame, 1.5)
        self.frame = cv2.GaussianBlur(self.frame, (13, 13), cv2.BORDER_DEFAULT)
        self.frame = cv2.dilate(self.frame, kernel, iterations=2)
        self.frame = cv2.Canny(self.frame, threshold1=15, threshold2=50)
        self.frame = cv2.dilate(self.frame, kernel, iterations=1)

    def _isDropletEdge(self, contour):
        top = False
        down = False
        height, width = self.frame.shape 
        min_x = max_x = contour[0][0][0]
        for p in contour:
            y = p[0][1]
            x = p[0][0]

            if min_x > x:
                min_x = x
            if max_x < x:
                max_x = x 

            if y == 0:
                top = True
            elif y == height-1:
                down = True
            if top and down:
                return True, (max_x + min_x) // 2
        return False, -1 

    def _updateVelocity(self, previous_droplets):
        if len(self.droplets) > self.nb_new_droplets:
            if len(previous_droplets) <= len(self.droplets[self.nb_new_droplets:]):
                #It means that the first droplet of the previous_droplets is still on the screen
                self.velocity = self.droplets[self.nb_new_droplets] - previous_droplets[0]
                #print("Velocity update: {}".format(self.velocity))
                return True
        return False

    def _handleHyperparameters(self, previous_droplets):
        if self.update_flag:
            ret = self._updateVelocity(previous_droplets)
            if ret:
                self.counter = 0
                self.update_flag = False
        else:
            self.counter += 1


    #Update droplets positions from past frame, remove any droplets that should be out of the screen, given the average velocity of a droplet.
    #Returns: the number of new droplets 
    def _pushFrameUpdate(self, seen_droplets):
        height, width = self.frame.shape
        #Remove droplets that shouldn't be on the screen anymore, knowing the average velocity of a droplet
        previous_droplets = self.droplets
        if self.droplets is not None:
            self.droplets = [d for d in previous_droplets if d+self.velocity+self.diameter//2 < width]
        new_droplets = [d for d in seen_droplets if self.droplets == [] or self.droplets[0] > d]

        self.droplets = seen_droplets
        self.nb_new_droplets = len(new_droplets)

        if not self.update_flag:
            self.counter += 1
            self.update_flag = self.counter == self.update_every
        else:
            self._handleHyperparameters(previous_droplets)

    def _spotBestCandidate(self, x, candidates, tolerance_rate):
        possible_candidates = list()
        for c_x in candidates:
            lower_bound, higher_bound = x + (1-tolerance_rate)*self.diameter, x + (1+tolerance_rate)*self.diameter
            if c_x >= lower_bound and c_x <= higher_bound:
                possible_candidates.append(c_x)

        if len(possible_candidates):
            return max(possible_candidates)
        return -1

    def _spotDroplets(self, x_contours):
        remaining_contours = x_contours
        droplet_positions = []
        while remaining_contours is not None and remaining_contours != []:
            x = remaining_contours[0]
            best_candidate_x = self._spotBestCandidate(x, remaining_contours[1:], 0.2)
            if best_candidate_x == -1:
                remaining_contours.remove(x)
            else:
                droplet_pos = (best_candidate_x+x)//2
                droplet_positions.append(droplet_pos)
                remaining_contours = [r for r in remaining_contours if r > best_candidate_x]
        return droplet_positions

    def apply(self, frame) -> None: 
        self.frame = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY) 
        height, width = self.frame.shape 
        self.frame = self.frame.T[:4*width//5].T 
        self.frame = self.frame[height//2-30:height//2+30]
        self._applyFilters()
        
        self.center, self.radius = apply_hough_transform(self.frame)

        self.contours = []
        #Contains the x coordinate of each contour
        x_contours = [] 
        contours, hierarchy = cv2.findContours(self.frame, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        #contours = []
        if(contours != []):
            for i in range(len(contours)):
                is_droplet_edge, x = self._isDropletEdge(contours[i])
                if len(contours[i]) > 1 and is_droplet_edge:
                    self.contours.append(contours[i])
                    x_contours.append(x)

        seen_droplets = self._spotDroplets(x_contours[::-1])
        self._pushFrameUpdate(seen_droplets)
        return self.droplets[:self.nb_new_droplets], self.diameter//2

    def draw(self):
        self.frame = cv2.cvtColor(self.frame, cv2.COLOR_GRAY2BGR)
        self.frame = cv2.drawContours(self.frame, self.contours, -1, (0, 255, 0))
        return self.frame

    def drawNewDroplets(self, frame):
        height, width, color = frame.shape 
        for i in range(self.nb_new_droplets):
            x = self.droplets[i]
            top_left = (x-self.diameter//2, 0)
            bottom_right = (x+self.diameter//2, height)
            cv2.rectangle(frame, top_left, bottom_right, (0, 255, 0), 2)






