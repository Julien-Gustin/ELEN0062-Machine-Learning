import cv2
import numpy as np
from droplet_detector import DropletDetector     
from cell import *

if __name__ == "__main__":
    cap = cv2.VideoCapture("data/group20.mp4")
    frame = None
    
    dd = DropletDetector(300, 300, 5)
    frameID = 1                      
    while(cap.isOpened()):
        ret, frame = cap.read()   
        if not ret:
            break
        dd.apply(frame)
        #frame = dd.draw()
        dd.drawNewDroplets(frame)

        cv2.putText(frame, '{}'.format(frameID), (0, 230), cv2.FONT_HERSHEY_SIMPLEX, 2, (255, 255, 0), 2, cv2.LINE_AA)
        cv2.imshow("Droplets", frame)
        frameID += 1
        if frameID >= 401 and cv2.waitKey() == 27:
            break  # esc to quit

    cap.release()
    cv2.destroyAllWindows()