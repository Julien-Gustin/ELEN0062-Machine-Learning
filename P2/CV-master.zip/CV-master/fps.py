import cv2
import numpy as np
from droplet_detector import DropletDetector          
from utils import apply_hough_transform
from imutils.video import FPS
from cell import *
import utils 

if __name__ == "__main__":
    cap = cv2.VideoCapture("data/group4.mp4")
    frame = None
    dd = DropletDetector(300, 300, 100)  
    cell_detector = CellsCounter()
    cnt_dico = {}
    fps = FPS().start()                     
    while(cap.isOpened()):
        ret, frame = cap.read()  
        if not ret:
            break
        droplet_x, radius = dd.apply(frame)
        for d in droplet_x:
            cropped_frame = get_cropped_frame(frame, d, radius)
            cnt, filtered_frame = cell_detector.execute(cropped_frame)
            #utils.display(frame, 2, cnt=None)
            #utils.display(filtered_frame, name="ROI")
            if cnt not in cnt_dico.keys():
                cnt_dico[cnt] = 0
            cnt_dico[cnt] += 1
            if cv2.waitKey() == 27: 
                    break
        fps.update()
    fps.stop()
    print("[INFO] approx. FPS: {:.2f}".format(fps.fps()))
    print(cnt_dico)

    cap.release()
    cv2.destroyAllWindows()